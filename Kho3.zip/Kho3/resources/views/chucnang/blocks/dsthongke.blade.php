<div class="span3">
        <div class="box">
            <div class="box-header">
                <p><b>Thống kê</b></p>
            </div>
            <div class="box-content">
                <form class="form-inline">
                <a href="{!! URL::route('chucnang.khohang.tongton') !!}" class="btn btn-default btn-lg btn-block" > Tồn kho tổng hợp</a>
                <a href="{!! URL::route('chucnang.khohang.nhomton') !!}" class="btn btn-default btn-lg btn-block" > Nhóm vật tư</a>
                <a href="{!! URL::route('chucnang.khohang.chatluongton') !!}" class="btn btn-default btn-lg btn-block" > Chất lượng vật tư</a>
                <a href="{!! URL::route('chucnang.khohang.nppton') !!}" class="btn btn-default btn-lg btn-block" > Nhà phân phối</a>
                </form>
            </div>
        </div>
    </div>