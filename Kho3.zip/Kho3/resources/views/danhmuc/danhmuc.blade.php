@extends('master')
@section('danhmuc')
<div class="body-nav body-nav-horizontal body-nav-fixed">
                        <div class="container">
                            <ul>
                                {{--<li>--}}
                                    {{--<a href="{!! URL::route('danhmuc.khuvuc.getList') !!}">--}}
                                        {{--<img src="{{ url('public/lib/images/khuvuc.png')}}" width="40px" height="30px" style="margin-top:-10px;" ><br> Khu vực--}}
                                    {{--</a>--}}
                                {{--</li>--}}
                                <li>
                                    <a href="{!! URL::route('danhmuc.nhasanxuat.getList') !!}">
                                        <img src="http://localhost/Kho2/public/lib/images/test.png" width="40px" height="30px" style="margin-top:-10px;"><br> Nhà sản xuất
                                    </a>
                                </li>
                                <li>
                                    <a href="{!! URL::route('danhmuc.nhaphanphoi.getList') !!}">
                                        <img src="http://localhost/Kho2/public/lib/images/test.png" width="40px" height="30px" style="margin-top:-10px;"><br> Nhà phân phối
                                    </a>
                                </li>
                                <li>
                                    <a href="{!! URL::route('danhmuc.vattu.getList') !!}">
                                        <img src="http://localhost/Kho2/public/lib/images/test.png" width="37px" height="30px" style="margin-top:-10px;"><br> Vật tư
                                    </a>
                                </li>
                                <li>
                                    <a href="{!! URL::route('danhmuc.nhomvattu.getList') !!}">
                                        <img src="http://localhost/Kho2/public/lib/images/test.png" width="37px" height="30px" style="margin-top:-10px;"><br> Nhóm vật tư
                                    </a>
                                </li>
                                <li>
                                    <a href="{!! URL::route('danhmuc.donvitinh.getList') !!}">
                                        <img src="http://localhost/Kho2/public/lib/images/test.png" width="39px" height="30px" style="margin-top:-10px;"><br> Đơn vị tính
                                    </a>
                                </li>
                                <li>
                                    <a href="{!! URL::route('danhmuc.chatluong.getList') !!}">
                                        <img src="http://localhost/Kho2/public/lib/images/test.png" width="27.5px" height="30px" style="margin-top:-10px;"><br> Chất lượng
                                    </a>
                                </li>
                                <li>
                                    <a href="{!! URL::route('danhmuc.kho.getList') !!}">
                                        <img src="http://localhost/Kho2/public/lib/images/test.png" width="43px" height="30px" style="margin-top:-15px;"><br> Kho
                                    </a>
                                </li>
                                <li>
                                    <a href="{!! URL::route('danhmuc.congtrinh.getList') !!}">
                                        <img src="http://localhost/Kho2/public/lib/images/test.png" width="39px" height="30px" style="margin-top:-10px;"><br> Bộ phậm
                                    </a>
                                </li>
                                </li>
                                <!-- <li>
                                    <a href="{!! URL::route('danhmuc.mucdich.getList') !!}">
                                        <img src="{{ url('public/lib/images/mucdich.png')}}" width="37px" height="30px" style="margin-top:-10px;"><br> Mục đích
                                    </a>
                                </li> -->
                                <!-- <li>
                                    <a href="{!! URL::route('danhmuc.phongban.getList') !!}">
                                        <img src="{{ url('public/lib/images/phongban.png')}}" width="40px" height="30px" style="margin-top:-10px;"><br> Phòng ban
                                    </a>
                                </li> -->
                                <li>
                                    <a href="{!! URL::route('danhmuc.nhanvien.getList') !!}">
                                        <img src="http://localhost/Kho2/public/lib/images/test.png" width="37px" height="30px" style="margin-top:-10px;"><br> Nhân viên
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>

@stop

