@extends('trogiup.trogiup')
@section('header')
<section class="nav nav-page">
    <div class="container">
        <div class="row">
            <div class="span7">
                <header class="page-header">
                    <h3>Hướng dẫn sử dụng<br/>
                    </h3>
                </header>
            </div>
        </div>
    </div>
</section>
@stop
@section('content')
    
@stop
