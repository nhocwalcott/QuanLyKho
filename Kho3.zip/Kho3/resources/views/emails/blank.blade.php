<b>Liên hệ</b>

<table  style="border-style: ridge;">
	<thead>
		<tr>
			<th width="200" style="border-style: dotted; border-width: 1px;">Email</th>
			<th width="200" style="border-style: dotted; border-width: 1px;">Nhân viên</th>
			<th width="600" style="border-style: dotted; border-width: 1px;">Nội dung</th>
		</tr>
	</thead>
	<tbody>
		<tr>
			<td width="200" style="border-style: solid; border-width: 1px;">{{$email}}</td>
			<td width="200" style="border-style: solid; border-width: 1px;">{{$name}}</td>
			<td width="600" style="border-style: solid; border-width: 1px;">{{$content}}</td>
		</tr>
	</tbody>
</table>